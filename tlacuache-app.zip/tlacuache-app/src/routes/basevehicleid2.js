const express = require('express');
const router = express.Router();
const fs = require('fs');
const uuidv4 = require('uuid/v4');
var request = require('request');

 


router.get('/models:modelid', (req, res) => {
  const { modelid } = req.params;

  
  const A = require('../apk/chocolopas/bd/token.json');
  const C = 'Bearer ' + A;

  
  var options = {
    'method': 'GET',
    'url': `http://tlacuache.racing:8055/items/models/${modelid}?export=json&fields[]=basevehicles.basevehicleid,basevehicles.yearid`,
    //'url': 'http://tlacuache.racing:8055/items/basevehicles/2?export=json&fields[]=aplications.aplications_aplicationid.mastercodeid.mastercodeid,aplications.aplications_aplicationid.mastercodeid.categoryid.categoryname',
    //'url': 'http://tlacuache.racing:8055/items/mastercodes?export=json&fields[]=subcategoryid.subcategoryname',
    
   
    'headers': {
      'Authorization': C,
      'Content-Type': 'application/json',
    }};
  request(options, function (error, response) {
    if (error) throw new Error(error);
    const res0 = response.body;
    const res1 = JSON.parse(res0);
    //const makes = res1.models
    //fs.writeFileSync('./directustoken.json', `"${re1.data.token}"`)
    
  
  console.log(res0);
  
  res.render('models27');

  });




});

module.exports = router;