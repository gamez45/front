const express = require('express');
const router = express.Router();
const fs = require('fs');
const uuidv4 = require('uuid/v4');
var request = require('request');



/*
router.get('/', (req, res) => {
  const A = require('../apk/chocolopas/bd/token.json')
  res.render('index', {A});
});
*/
router.get('/', (req, res) => {
   res.render('index');
});

router.post('/', (req, res) => {
const token = []

  const { email, password } = req.body;

  if (!email || !password ) {
    res.status(400).send("Ingresar datos");
    return;
  }

  var newLogin = {
    email,
    password
    
  };

  console.log(newLogin)

  
  var options = {
    'method': 'POST',
    'url': 'http://tlacuache.racing:8055/auth/login',
    'headers': {
      'Authorization': 'Bearer',
      'Content-Type': 'application/json',
     },
    body: JSON.stringify({"email": newLogin.email,"password": newLogin.password})
  
  };
  request(options, function (error, response) {
    try{
    //const res0 = response.body;
    //const re1 = JSON.parse(res0)
    //fs.writeFileSync('./directustoken.json', `"${re1.data.token}"`)
    const res0 = response.body;
    
    const respa = JSON.parse(res0);
    const respa0 = respa.data;
    const token0 = respa0.access_token;
    const A = token0;
    
  
    token.push(A)
  
   fs.writeFileSync('./src/apk/chocolopas/bd/token.json', JSON.stringify(`${token}`));
  console.log(token)

  res.render('inicio');

}catch(e){

  res.render('index');
}
  });
  

  
  
});





module.exports = router;