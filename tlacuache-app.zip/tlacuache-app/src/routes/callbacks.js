const express = require('express');
const router = express.Router();
const fs = require('fs');
const uuidv4 = require('uuid/v4');
var request = require('request');


router.get('/callbacks', async (req, res) => {

  
  
    res.render('inicio');

  });
   
  
  
    


 


module.exports = router;