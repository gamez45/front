const express = require('express');
const router = express.Router();
const fs = require('fs');
const uuidv4 = require('uuid/v4');
var request = require('request');


router.get('/catalogo', async (req, res) => {

  const A = require('../apk/chocolopas/bd/token.json');
  const C = 'Bearer ' + A;

  
  var options = {
    'method': 'GET',
    'url': 'http://tlacuache.racing:8055/items/makes?export=json&fields[]=makeid,makename,makebrand',
    //'url': 'http://tlacuache.racing:8055/items/makes/33?export=json&fields[]=models.modelid,models.modelname,models.modelimg',
    //'url': 'http://tlacuache.racing:8055/items/models/27?export=json&fields[]=basevehicles.basevehicleid,basevehicles.yearid',
    //'url': 'http://tlacuache.racing:8055/items/basevehicles/2?export=json&fields[]=aplications.aplications_aplicationid.mastercodeid.mastercodeid,aplications.aplications_aplicationid.mastercodeid.categoryid.categoryname',
    //'url': 'http://tlacuache.racing:8055/items/mastercodes?export=json&fields[]=subcategoryid.subcategoryname',
    
   
    'headers': {
      'Authorization': C,
      'Content-Type': 'application/json',
    }};
  request(options, function (error, response) {
    if (error) throw new Error(error);
    const res0 = response.body;
    const res1 = JSON.parse(res0);
    //fs.writeFileSync('./directustoken.json', `"${re1.data.token}"`)
    
  
  console.log(JSON.stringify(res1));
  
  res.render('catalogo', {res1});

  });
   
    
});

router.get('/catalogo/makes/:makename/:makeid', (req, res) => {
  const { makeid, makename } = req.params;

  
  const A = require('../apk/chocolopas/bd/token.json');
  const C = 'Bearer ' + A;
 const B = {"make":makename};
  
  var options = {
    'method': 'GET',
    'url': `http://tlacuache.racing:8055/items/makes/${makeid}?export=json&fields[]=models.modelid,models.modelname,models.modelimg`,
    //'url': 'http://tlacuache.racing:8055/items/models/27?export=json&fields[]=basevehicles.basevehicleid,basevehicles.yearid',
    //'url': 'http://tlacuache.racing:8055/items/basevehicles/2?export=json&fields[]=aplications.aplications_aplicationid.mastercodeid.mastercodeid,aplications.aplications_aplicationid.mastercodeid.categoryid.categoryname',
    //'url': 'http://tlacuache.racing:8055/items/mastercodes?export=json&fields[]=subcategoryid.subcategoryname',
    
   
    'headers': {
      'Authorization': C,
      'Content-Type': 'application/json',
    }};
  request(options, function (error, response) {
    if (error) throw new Error(error);
    const res0 = response.body;
    const res1 = JSON.parse(res0);
    const makes = res1.models;
    makes.push(B);
   
    fs.writeFileSync('./src/apk/chocolopas/bd/models.json', JSON.stringify(makes));
    
  
  console.log(makes);
  
  res.redirect('/models');

  });

console.log(makeid)


});

/*
router.get('/makes:makeid', (req, res) => {
  const { makeid } = req.params;

  
  const A = require('../apk/chocolopas/bd/token.json');
  const C = 'Bearer ' + A;

  
  var options = {
    'method': 'GET',
    'url': `http://tlacuache.racing:8055/items/makes/${makeid}?export=json&fields[]=models.modelid,models.modelname,models.modelimg`,
    //'url': 'http://tlacuache.racing:8055/items/models/27?export=json&fields[]=basevehicles.basevehicleid,basevehicles.yearid',
    //'url': 'http://tlacuache.racing:8055/items/basevehicles/2?export=json&fields[]=aplications.aplications_aplicationid.mastercodeid.mastercodeid,aplications.aplications_aplicationid.mastercodeid.categoryid.categoryname',
    //'url': 'http://tlacuache.racing:8055/items/mastercodes?export=json&fields[]=subcategoryid.subcategoryname',
    
   
    'headers': {
      'Authorization': C,
      'Content-Type': 'application/json',
    }};
  request(options, function (error, response) {
    if (error) throw new Error(error);
    const res0 = response.body;
    const res1 = JSON.parse(res0);
    const makes = res1.models
    //fs.writeFileSync('./directustoken.json', `"${re1.data.token}"`)
    
  
  console.log(makes);
  
  res.render('makes33', {makes});

  });

console.log(makeid)


});



const express = require('express');
const router = express.Router();
const fs = require('fs');
const uuidv4 = require('uuid/v4');
var request = require('request');

 


router.get('/models:modelid', (req, res) => {
  const { modelid } = req.params;

  
  const A = require('../apk/chocolopas/bd/token.json');
  const C = 'Bearer ' + A;

  
  var options = {
    'method': 'GET',
    'url': `http://tlacuache.racing:8055/items/models/${modelid}?export=json&fields[]=basevehicles.basevehicleid,basevehicles.yearid`,
    //'url': 'http://tlacuache.racing:8055/items/basevehicles/2?export=json&fields[]=aplications.aplications_aplicationid.mastercodeid.mastercodeid,aplications.aplications_aplicationid.mastercodeid.categoryid.categoryname',
    //'url': 'http://tlacuache.racing:8055/items/mastercodes?export=json&fields[]=subcategoryid.subcategoryname',
    
   
    'headers': {
      'Authorization': C,
      'Content-Type': 'application/json',
    }};
  request(options, function (error, response) {
    if (error) throw new Error(error);
    const res0 = response.body;
    const res1 = JSON.parse(res0);
    const years = res1.basevehicles;
    //fs.writeFileSync('./directustoken.json', `"${re1.data.token}"`)
    
  
  console.log(res0);
  
  res.render('models27', {years});

  });




});

module.exports = router;


<!DOCTYPE html>
<html lang="en">

<head>
  <% include partials/header %>

  <style>

.img-model{
  display: inline-block;
    width: 10%;
   
    

}



h1 {
    font-size: 2em;
    color: #6c6c6c;
    font-weight: 400;
    display: block;
    font-size: 2em;
    margin-block-start: 0.67em;
    margin-block-end: 0.67em;
    margin-inline-start: 0px;
    margin-inline-end: 0px;
    font-weight: bold;

}

.main-catalog-7Zap, .main-catalog-7Zap h2, h1 {
    font-family: Navigo;
}

    .mt-2, .my-2 {
    margin-top: .5rem!important;
}

.row {
    margin-right: 0!important;
    margin-left: 0!important;
}

.zp-element-title {
    font-family: Verdana,sans-serif;
    color: #428bca;
}

.autocat-array-block {
    height: 170px;
    font-size: 17px;
}

.autocat-array-icon {
    width: 100%;
    height: 115px;
    text-align: center;
}

.autocat-array-center {
    width: 100%;
    height: 100%;
    position: relative;
    top: 0;
    left: 0;
    white-space: nowrap;
    text-align: center;
    font-size: 0;
}

.autocat-array-center:before {
    height: 100%;
    display: inline-block;
}

.autocat-array-img {
    width: auto;
    max-width: 100%;
    height: auto;
    max-height: 100%;
    white-space: normal;
    text-align: left;
    background: #fff;
    display: inline-block;
}

.autocat-array-block .zp-element-title {
    width: 100%;
    display: inline-block;
    text-align: center;
    white-space: nowrap;
    font-size: 16px;
}

@media only screen and (max-width: 575px) {
.zp-array .link-wrap {
    padding: 1px;
    overflow: hidden;
    margin: 4px 1%;
    width: 31.333%;
}
.zp-array .autocat-array-block {
    width: 100%;
    min-width: auto;
    max-width: none;
    height: 160px;
    padding: 0;
}

.zp-array .autocat-array-block .zp-element-title {
    font-size: .75em;
}

}

  </style>
</head>

<body>


  <% include partials/navigation %>

  
  <div class="zp-array">
    <h1 class="mt-2"></h1>
    <div class="row d-flex justify-content-start align-items-start w-100">
     

        <%if ( years.length> 0) {%>

          <% years.forEach(function(year) { %>
   
        <a href="/" class="link-wrap">
          <div class="tla-array-block pointer mb-md-2 mr-md-2">
            <div class="tla-array-icon">
              <div class="tla-array-center"></div>
            </div> <span class="zp-element-title"> <%= year.yearid %> </span>
          </div>
  
        </a> 
        <%})%>
  
  
        <%} else {%>
          
          <%}%>
      </div>
  </div>



   
      
   

    
  <% include partials/footer %>
</div>
</main>
</div>
</div>

  
</body>
</html>

</body>

</html>
*/

module.exports = router;