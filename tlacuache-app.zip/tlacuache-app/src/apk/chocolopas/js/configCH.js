const jToken = require('../bd/token-chocolopas.json');


var CFd = {

	choco_api_url: 'http://tlacuache.racing:8055',
	auth_url: '/auth/login',
	email: "luis@tlacuache.racing",
	password: "1420",
	token: jToken,
	
};



var collection = {
	_make: '/items/make'

};


exports.CFd = CFd;
exports.collection = collection;
