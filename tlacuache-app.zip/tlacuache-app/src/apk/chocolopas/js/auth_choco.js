var request = require('request');
const fs = require('fs');
var CFd = require('./configCH').CFd;

token = []

var options = {
  'method': 'POST',
  'url': CFd.choco_api_url+CFd.auth_url,
  'headers': {
    'Authorization': 'Bearer',
    'Content-Type': 'application/json',
   },
  body: JSON.stringify({"email": CFd.email,"password": CFd.password})

};
request(options, function (error, response) {
  if (error) throw new Error(error);
  //const res0 = response.body;
  //const re1 = JSON.parse(res0)
  //fs.writeFileSync('./directustoken.json', `"${re1.data.token}"`)
  const res0 = response.body;
  
  const respa = JSON.parse(res0);
  const respa0 = respa.data;
  const token0 = respa0.access_token;
  const A = 'Bearer ' + token0;
  

  token.push(A)

 fs.writeFileSync('./src/apk/chocolopas/bd/token.json', JSON.stringify(`${token}`));
console.log(token)
});



 

