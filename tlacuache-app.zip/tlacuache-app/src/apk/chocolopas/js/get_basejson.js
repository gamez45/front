var request = require('request');
const fs = require('fs');

token = []
categoryarray = []
try{
var options = {
  'method': 'POST',
  'url': 'http://autoparteschocolopas.xyz:8060/auth/login',
  'headers': {
    'Authorization': 'Bearer',
    'Content-Type': 'application/json',
   },
  body: JSON.stringify({"email": "luis@chocolopas.com","password": "Noviembre"})

};
request(options, function (error, response) {
  if (error) throw new Error(error);
  //const res0 = response.body;
  //const re1 = JSON.parse(res0)
  //fs.writeFileSync('./directustoken.json', `"${re1.data.token}"`)
  res0 = response.body
  respa = JSON.parse(res0)
  respa0 = respa.data
  token0 = respa0.access_token

  token.push(token0)

 // fs.writeFileSync('./token-chocolopas.json', JSON.stringify(`${token}`));


try{
  const auth ='Bearer ' + token
var year="2000"
var make="Dodge"
var model="Dakota"
  
var options = {
  'method': 'GET',
  //'url': `http://autoparteschocolopas.xyz:8060/items/vc_basevehicle?&fields=basevehicleid,makeid.makename&fields=modelid.modelname&filter={"yearid":{"_contains":"${year}"}}`,
  //'url': `http://autoparteschocolopas.xyz:8060/items/vc_basevehicle`,
  'url': `autoparteschocolopas.xyz:8060/items/vc_basevehicle?fields=yearid,makeid.makename,modelid.modelname`,
  'headers': {
    'Authorization': auth,
    'Content-Type': 'application/json',
    
    
  },
  //body: JSON.stringify({"email": "luis@chocolopas.com","password": "Noviembre"})

};
request(options, function (error, response) {
  if (error) throw new Error(error);
  const res0 = response.body;
 
  //const re1 = JSON.parse(res0)
  //fs.writeFileSync('./directustoken.json', `"${re1.data.token}"`)
  
  
  jsonres = JSON.parse(res0)
  const res1 = jsonres.data

  
  const res2 = res1
  /*const res3 = res2.makeid
  var marca = res3.makename
  console.log(marca)*/
  console.log(jsonres)
  

   
  

  //console.log(jsonres.data.length)
 // fs.writeFileSync('./token-chocolopas.json', JSON.stringify(`${token}`));

});




}catch(e){console.log(e)}});


}catch(e){console.log(e)}




 

