const util = require('util');
const sleep = util.promisify(setTimeout);
const fs = require('fs-extra');

async function id_items () {
    const stock_all = require('../js/jaja.json');
    const items_all = require('../json/all_codigos.json');
    var array_id_items = []
        for(let i of items_all) {
    let iterations =0;
    let found_id_items = stock_all.some((obj, ) => {
        iterations++;
        if(obj.id === i.code) {
             return true;}
             return false});
             array_id_items.push(`{"id": "${i.code}", "exist": "${found_id_items.toString()}"}`)};
    
             
    await fs.writeFile('./validar.json', `[${array_id_items}]`)
        let validador_id_items = require('./validar.json');
        let false_id_items =  validador_id_items.filter(function (element) {
         return element.exist == 'false';
        });
        let valiobj_id_items = JSON.stringify(false_id_items)
    
   
   await fs.writeFile('./porsubir.json', `${valiobj_id_items}`)
    
    } id_items()