var request = require('request');
const fs = require('fs');

token = []

try{
var options = {
  'method': 'POST',
  'url': 'http://autoparteschocolopas.xyz:8060/auth/login',
  'headers': {
    'Authorization': 'Bearer',
    'Content-Type': 'application/json',
   },
  body: JSON.stringify({"email": "luis@chocolopas.com","password": "Noviembre"})

};
request(options, function (error, response) {
  if (error) throw new Error(error);
  //const res0 = response.body;
  //const re1 = JSON.parse(res0)
  //fs.writeFileSync('./directustoken.json', `"${re1.data.token}"`)
  res0 = response.body
  respa = JSON.parse(res0)
  respa0 = respa.data
  token0 = respa0.access_token

  token.push(token0)

 // fs.writeFileSync('./token-chocolopas.json', JSON.stringify(`${token}`));


try{
  const auth ='Bearer ' + token

  
var options = {
  'method': 'GET',
  'url': `http://autoparteschocolopas.xyz:8060/items/ml_items`,
  //'url': `http://autoparteschocolopas.xyz:8060/items/vc_basevehicle`,
  'headers': {
    'Authorization': auth,
    'Content-Type': 'application/json',
    
    
  },
  //body: JSON.stringify({"email": "luis@chocolopas.com","password": "Noviembre"})

};
request(options, function (error, response) {
  if (error) throw new Error(error);
  const res0 = response.body;
 
  //const re1 = JSON.parse(res0)
  //fs.writeFileSync('./directustoken.json', `"${re1.data.token}"`)
  
  
  jsonres = JSON.parse(res0)
  const res1 = jsonres.data

  
  const res2 = res1
  /*const res3 = res2.makeid
  var marca = res3.makename
  console.log(marca)*/
  console.log(res1)
  console.log(res0)

  //console.log(jsonres.data.length)
 // fs.writeFileSync('./token-chocolopas.json', JSON.stringify(`${token}`));

});




}catch(e){console.log(e)}});


}catch(e){console.log(e)}




 

