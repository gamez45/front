var request = require('request');
const fs = require('fs');
var CFd = require('./configuracion').CFd;
var collection = require('./configuracion').collection;
//const auth ='Bearer ' + CFd.token;
//const auth = 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjE3ODdhNTU5LTJjNzItNDQ1MC04NWQxLWRiMTYxOTFkZmNlZCIsImlhdCI6MTYyMjE5ODA5MiwiZXhwIjoxNjIyMTk4OTkyfQ.Wag941Rxj4XVVyII0W_DPMS2P4xH4ZgdU7HMT84cmTA';




const json_file = require('../json/all_codigos.json');



const array = []

async function fPost() {


  var options = {
    'method': 'POST',
    'url': 'https://meli.autoparteschocolopas.xyz/items/erp_suppliersparts',
    'headers': {
      'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjE3ODdhNTU5LTJjNzItNDQ1MC04NWQxLWRiMTYxOTFkZmNlZCIsImlhdCI6MTYyMjE5ODA5MiwiZXhwIjoxNjIyMTk4OTkyfQ.Wag941Rxj4XVVyII0W_DPMS2P4xH4ZgdU7HMT84cmTA',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify([
      {"id":"FFVK0411"},{"id":"FFVK0412"},{"id":"FFVK0421"},{"id":"FFVK0431"},{"id":"FFVK0432"},{"id":"FFVK0501"},{"id":"FFVK0502"},{"id":"FFVK0511"},{"id":"FFVK0512"},{"id":"FFVK0581"},{"id":"FFVK0582"},{"id":"FFVK0591"},{"id":"FFVK0592"},{"id":"FFVK1301"},{"id":"FFVK1302"},{"id":"FFVK1521"},{"id":"FFVK1522"},{"id":"FFVK2351"},{"id":"FFVK2352"},{"id":"FFVK3611"},{"id":"FFVK3612"},{"id":"FFVK3621"},{"id":"FFVK3622"},{"id":"FFVK4111"},{"id":"FFVK4511"},{"id":"FFVK8101"},{"id":"FFVK8102"},{"id":"FFVK9001"},{"id":"FFVK9002"},{"id":"FFVN1201"},{"id":"FFVN1202"},{"id":"FFVN1301"},{"id":"FFVN1302"},{"id":"FFVN1401"},{"id":"FFVN1402"},{"id":"FFVN1411"},{"id":"FFVN1412"},{"id":"FFVN2771"},{"id":"FFVN2772"},{"id":"FFVN3162"},{"id":"FFVN3221"},{"id":"FFVN3231"},{"id":"FFVN3232"},{"id":"FFVN3251"},{"id":"FFVN3271"},{"id":"FFVN3272"},{"id":"FFVN3281"},{"id":"FFVN3282"},{"id":"FFVT1671"},{"id":"FFVV0121"},{"id":"FFVV0122"},{"id":"FFVV1511"},{"id":"FFVV1512"},{"id":"FFVV2111"},{"id":"FFVV2112"},{"id":"FFVZ0102"},{"id":"ACNK1400"},{"id":"ACNV1100"},{"id":"AANC1100"},{"id":"AANC1200"},{"id":"AANC1900"},{"id":"AANC2000"},{"id":"AANC2500"},{"id":"AANC2900"},{"id":"AANC2910"},{"id":"AANC4800"},{"id":"AAND0300"},{"id":"AANF0600"},{"id":"AANF2400"},{"id":"AANI0300"},{"id":"AANK0410"},{"id":"AANK1400"},{"id":"AANK2500"},{"id":"AANK4500"},{"id":"AANN2800"},{"id":"AANP0400"},{"id":"AANP1100"},{"id":"AANT2310"},{"id":"AANV1100"},{"id":"AANV2400"},{"id":"AANV2700"},{"id":"AGNC1520"},{"id":"AGNC1900"},{"id":"AGNC2000"},{"id":"AGNC2300"},{"id":"AGNC2910"},{"id":"AGNC3000"},{"id":"AGNC5000"},{"id":"AGND0300"},{"id":"AGNH0100"},{"id":"AGNH0110"},{"id":"AGNK0110"},{"id":"AGNK1300"},{"id":"AGNK1310"},{"id":"AGNK2500"},{"id":"AGNN2600"},{"id":"AGNN2610"},{"id":"ADNN3500"},{"id":"EFRN0100"},{"id":"EFRN0500"},{"id":"EFRN0510"},{"id":"EFRN0600"},{"id":"SHNC1101"},{"id":"SHNC1102"},{"id":"SHNC2101"},{"id":"SHNC2102"},{"id":"SHND0301"},{"id":"SHND0302"},{"id":"SHND0401"},{"id":"SHND0402"},{"id":"SHND1001"},{"id":"SHND1002"},{"id":"SHNF0101"},{"id":"SHNF0102"},{"id":"SHNF0111"},{"id":"SHNF0112"},{"id":"SHNF0150"},{"id":"SHNF0201"},{"id":"SHNF0202"},{"id":"SHNF0301"},{"id":"SHNF0302"},{"id":"SHNF0311"},{"id":"SHNF0312"},{"id":"SHNF0321"},{"id":"SHNF0322"},{"id":"SHNF0400"},{"id":"SHNF0401"},{"id":"SHNF0402"},{"id":"SHNF0411"},{"id":"SHNF0412"},{"id":"SHNF0421"},{"id":"SHNF0422"},{"id":"SHNF0431"},{"id":"SHNF0432"},{"id":"SHNF0501"},{"id":"SHNF0502"},{"id":"SHNF0701"},{"id":"SHNF0702"},{"id":"SHNF1501"},{"id":"SHNF1502"},{"id":"SHNF1801"},{"id":"SHNF1802"},{"id":"SHNF1811"},{"id":"SHNF1812"},{"id":"SHNF1821"},{"id":"SHNF1822"},{"id":"SHNF2001"},{"id":"SHNF2002"},{"id":"SHNF2011"},{"id":"SHNF2012"},{"id":"SHNF3401"},{"id":"SHNF3402"},{"id":"SHNF3601"},{"id":"SHNF3602"},{"id":"SHNF4601"},{"id":"SHNF4602"},{"id":"SHNF4611"},{"id":"SHNF4612"},{"id":"SHNK1311"},{"id":"SHNK1312"},{"id":"SHNK1320"},{"id":"SHNK1350"},{"id":"SHNK1360"},{"id":"SHNK1401"},{"id":"SHNK1402"},{"id":"SHNK1411"},{"id":"SHNK1412"},{"id":"SHNK1421"},{"id":"SHNK1422"},{"id":"SHNK1601"},{"id":"SHNK1602"},{"id":"SHNK2300"},{"id":"SHNK2501"},{"id":"SHNK2502"},{"id":"SHNK2601"},{"id":"SHNK2602"},{"id":"SHNK3600"},{"id":"SHNK3601"},{"id":"SHNK3602"},{"id":"SHNK4001"},{"id":"SHNK4002"},{"id":"SHNK4101"},{"id":"SHNK4102"},{"id":"SHNK9000"},{"id":"SHNK9001"},{"id":"SHNK9002"},{"id":"SHNK9011"},{"id":"SHNK9012"},{"id":"SHNN1701"},{"id":"SHNN1702"},{"id":"SHNO0200"},{"id":"SHNT0211"},{"id":"SHNT0212"},{"id":"DHNF0100"},{"id":"DHNF0401"},{"id":"DHNF0402"},{"id":"DHNF2400"},{"id":"DHNF2501"},{"id":"DHNF2502"},{"id":"DHNK0210"},{"id":"DHNK0500"},{"id":"DHNK0700"},{"id":"DHNK1500"},{"id":"DHNS0500"},{"id":"BMNC1800"},{"id":"BMNC2000"},{"id":"BMNC2300"},{"id":"BMNC2310"},{"id":"BMNC2350"},{"id":"BMNC2600"},{"id":"BMNC2610"},{"id":"BMNC2620"},{"id":"BMNC2630"},{"id":"BMNC2640"},{"id":"BMNC3050"},{"id":"BMNC3060"},{"id":"BMNC3400"},{"id":"BMNC3800"},{"id":"BMNC3900"},{"id":"BMNC3910"},{"id":"BMNC4810"},{"id":"BMNC4850"},{"id":"BMNC4860"},{"id":"BMNC6900"},{"id":"BMNC6950"},{"id":"BMNC7200"},{"id":"BMNC7250"},{"id":"BMNF1400"},{"id":"BMNF2450"},{"id":"BMNF2460"},{"id":"BMNF2510"},{"id":"BMNF4650"},{"id":"BMNH0250"},{"id":"BMNK0100"},{"id":"BMNK0150"},{"id":"BMNK0250"},{"id":"BMNK0300"},{"id":"BMNK0400"},{"id":"BMNK0450"},{"id":"BMNK0700"},{"id":"BMNK0710"},{"id":"BMNK0720"},{"id":"BMNK0730"},{"id":"BMNK0750"},{"id":"BMNK0760"},{"id":"BMNK0770"},{"id":"BMNK1300"},{"id":"BMNK4050"},{"id":"BMNK9000"},{"id":"BMNK9050"},{"id":"BMNN1150"},{"id":"BMNN3200"},{"id":"BMNN3250"},{"id":"BMNN3260"},{"id":"BMNN3270"},{"id":"BMNT0350"},{"id":"BMNV0561"},{"id":"BMNV0562"},{"id":"EINN0204"},{"id":"CPNC0410"},{"id":"APNT0700"},{"id":"CRNC1200"},{"id":"CRNC1410"},{"id":"CRNC1800"},{"id":"CRNC1810"},{"id":"CRNC1826"},{"id":"CRNC1900"},{"id":"CRNC2000"},{"id":"CRNC2317"},{"id":"CRNC2500"},{"id":"CRNC2600"},{"id":"CRNC2610"},{"id":"CRNC2620"},{"id":"CRNC3000"},{"id":"CRNC3010"},{"id":"CRNC3020"},{"id":"CRNC3030"},{"id":"CRNC3400"},{"id":"CRNC3800"},{"id":"CRNC4800"},{"id":"CRNC4810"},{"id":"CRNC5000"},{"id":"CRNC5010"},{"id":"CRNC6900"},{"id":"CRNC6910"},{"id":"CRNC7200"},{"id":"CRND0300"},{"id":"CRNE0200"},{"id":"CRNF0400"},{"id":"CRNF0410"},{"id":"CRNF0420"},{"id":"CRNF0430"},{"id":"CRNF0500"},{"id":"CRNF0510"},{"id":"CRNF0530"},{"id":"CRNF0540"},{"id":"CRNF0600"},{"id":"CRNF1400"},{"id":"CRNF1500"},{"id":"CRNF1700"},{"id":"CRNF1800"},{"id":"CRNF1810"},{"id":"CRNF1820"},{"id":"CRNF1830"},{"id":"CRNF1840"},{"id":"CRNF1850"},{"id":"CRNF1860"},{"id":"CRNF2258"},{"id":"CRNF2400"},{"id":"CRNF2410"},{"id":"CRNF2420"},{"id":"CRNF2430"},{"id":"CRNF2500"},{"id":"CRNF2510"},{"id":"CRNF2520"},{"id":"CRNF2530"},{"id":"CRNF3600"},{"id":"CRNF3610"},{"id":"CRNF3620"},{"id":"CRNF4600"},{"id":"CRNF4610"},{"id":"CRNH0100"},{"id":"CRNH0110"},{"id":"CRNH0120"},{"id":"CRNH0130"},{"id":"CRNH0140"},{"id":"CRNH0150"},{"id":"CRNH0160"},{"id":"CRNH0170"},{"id":"CRNH0200"},{"id":"CRNH0210"},{"id":"CRNH0220"},{"id":"CRNH0240"},{"id":"CRNH0300"},{"id":"CRNH0320"},{"id":"CRNH0330"},{"id":"CRNH0400"},{"id":"CRNH0410"},{"id":"CRNH0500"},{"id":"CRNH0510"},{"id":"CRNH0520"},{"id":"CRNK0200"},{"id":"CRNK0210"},{"id":"CRNK0300"},{"id":"CRNK0340"},{"id":"CRNK0350"},{"id":"CRNK0420"},{"id":"CRNK0700"},{"id":"CRNK0710"},{"id":"CRNK0720"},{"id":"CRNK0730"},{"id":"CRNK0740"},{"id":"CRNK0810"},{"id":"CRNK0900"},{"id":"CRNK1200"},{"id":"CRNK1310"},{"id":"CRNK1320"},{"id":"CRNK1330"},{"id":"CRNK1340"},{"id":"CRNK1600"},{"id":"CRNK2500"},{"id":"CRNK4100"},{"id":"CRNK4110"},{"id":"CRNK4120"},{"id":"CRNK4500"},{"id":"CRNK4510"},{"id":"CRNK9000"},{"id":"CRNN2500"},{"id":"CRNN2510"},{"id":"CRNN2800"},{"id":"CRNN2900"},{"id":"CRNN3220"},{"id":"CRNS0500"},{"id":"CRNS0520"},{"id":"CRNS0600"},{"id":"CRNT0100"},{"id":"CRNT0120"},{"id":"CRNT0140"},{"id":"CRNT0600"},{"id":"CRNT0620"},{"id":"CRNT1210"},{"id":"CRNT1220"},{"id":"CRNV0710"},{"id":"CRNV1110"},{"id":"CRNV1500"},{"id":"CRNY0500"},{"id":"CRNZ0100"},{"id":"CRNZ0110"},{"id":"CRNZ0320"},{"id":"CRNZ0400"},{"id":"CRNZ0800"},{"id":"EANN0100"},{"id":"EANN0110"},{"id":"EANN0120"},{"id":"EANN1300"},{"id":"DTNC1400"},{"id":"DTNC2300"},{"id":"DTNC2600"},{"id":"DTNF0410"},{"id":"DTNF0600"},{"id":"DTNF1400"},{"id":"DTNF1803"},{"id":"DTNF1804"},{"id":"DTNF2400"},{"id":"DTNK0401"},{"id":"DTNK0402"},{"id":"DTNN1500"},{"id":"DTNN1510"},{"id":"DTNV1800"},{"id":"DTNV5101"},{"id":"DTRC9901"},{"id":"DTRC9902"},{"id":"DTRK0800"},{"id":"DTRK8100"},{"id":"DTRN0400"},{"id":"DTRN1101"},{"id":"DTRN1102"},{"id":"DTRS1311"},{"id":"DTRS1312"},{"id":"DONC0100"},{"id":"DONC0150"},{"id":"DONF1500"},{"id":"DONF1510"},{"id":"DONK0100"},{"id":"DONK0150"},{"id":"DONK0160"},{"id":"DONN0100"},{"id":"DONN0101"},{"id":"DONN0110"},{"id":"DONN0120"},{"id":"DONN0150"},{"id":"DONN0160"},{"id":"DONN0170"},{"id":"DONN0500"},{"id":"DVNV5102"},{"id":"GRRN0306"},{"id":"GRRC0112"},{"id":"GRRK0106"},{"id":"GRRV0104"},{"id":"GRNF0200"},{"id":"GRRN0400"},{"id":"IARN1300"},{"id":"IARV0200"},{"id":"IARN3400"},{"id":"IERK0100"},{"id":"IERV0200"},{"id":"IERV0100"},{"id":"IFRN0501"},{"id":"IFRN3400"},{"id":"IVRK0100"},{"id":"IVRN0200"},{"id":"IVRN1500"},{"id":"IVRN0900"},{"id":"IVRN0500"},{"id":"IVRV1610"},{"id":"MBNN0400"} ])

  };
  request(options, function (error, response) {
    if (error) throw new Error(error);
    console.log(response.body);
  });





} fPost();
/*
var index = array.length;

var array1 = array.slice(0, index/2);
var array2 = array.slice(index/2, index);


var index1 = array1.length;

var array11 = array.slice(0, index1/2 );
var array12 = array.slice(index1/2, index1);

var index2 = array2.length;

var array21 = array.slice(0, index2/2 );
var array22 = array.slice(index2/2, index1);


var arrayMaster = []

arrayMaster.push(array11,array12,array21,array22)

*/
/*
setTimeout(() => {
for(let k of array){


  setTimeout(() => {
try{


var options = {
  'method': 'POST',
  'url': CFd.choco_api_url+collection.catalogo_proveedores,
  'headers': {
    'Authorization': auth,
    'Content-Type': 'application/json',


  },
  body: JSON.stringify(k)

};



  setTimeout(() => {
    try{
request(options, function (error, response) {

  const res0 = response;
  //const re1 = JSON.parse(res0)
  //fs.writeFileSync('./directustoken.json', `"${re1.data.token}"`)


  console.log(res0)

 // fs.writeFileSync('./token-chocolopas.json', JSON.stringify(`${token}`));

})}catch(e){console.log(e)} ;},12000)

}catch(e){
  console.log(e)
}},1000)


}},12000)
}fPost();

*/