var request = require('request');
const _ = require('lodash');
const fs = require('fs');
var CFd = require('./configuracion').CFd;
var collection = require('./configuracion').collection;
const auth ='Bearer ' + CFd.token;
const jProduct = require('../json/all_codigos.json')

async function pathProducts(){
const json_file = require('../json/all_codigos.json')


for (var i=0; i<=10; i++){
  
  let grupo = _.filter(json_file, obj => _.some(obj, val => val === JSON.stringify(i)));
  console.log(grupo)
}



/*
for(let i of json_file){

jsonres = JSON.stringify(i)
jsonres0 = `[${jsonres}]`




try{
var options = {
  'method': 'PATH',
  'url': CFd.choco_api_url+collection.catalogo_proveedores,
  'headers': {
    'Authorization': JSON.stringify(auth),
    'Content-Type': 'application/json',
    
    
  },
  body: jsonres0

};

request(options, function (error, response) {
  if (error) throw new Error(error);
  const res0 = response.body;
  //const re1 = JSON.parse(res0)
  //fs.writeFileSync('./directustoken.json', `"${re1.data.token}"`)
  
  
  console.log(res0)

 // fs.writeFileSync('./token-chocolopas.json', JSON.stringify(`${token}`));

})}catch(e){
  console.log(e)
}



}*/};

pathProducts()

