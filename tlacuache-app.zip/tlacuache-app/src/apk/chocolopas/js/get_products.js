var request = require('request');
const _A = require('./auth_choco')
const fs = require('fs');
var CFd = require('./configCH').CFd;
var collection = require('./configCH').collection;



var options = {
  'method': 'GET',
  'url': CFd.choco_api_url+collection._make+'?fields[]=makename,makelogo,model.modelname,model.blueprint,model.basevehicle.yearid',
  'headers': {
    'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6ImM5NDE2ZGMwLTdmYWItNDNiOC05YzkyLTJkMjAxY2ZiZDA0NSIsImlhdCI6MTYzMDI1OTY1NCwiZXhwIjoxNjMwMjYwNTU0fQ.C0UeVA9JwgNYnEv0vZcwO-JXsCjxNjQlUHVSaSQvYms',
    'Content-Type': 'application/json',
  }};
request(options, function (error, response) {
  if (error) throw new Error(error);
  const res0 = response.body;
  //const re1 = JSON.parse(res0)
  //fs.writeFileSync('./directustoken.json', `"${re1.data.token}"`)
  
 
  var jId = JSON.parse(res0);
console.log(JSON.stringify(jId))

  






 // fs.writeFileSync('./token-chocolopas.json', JSON.stringify(`${token}`));

});



 

