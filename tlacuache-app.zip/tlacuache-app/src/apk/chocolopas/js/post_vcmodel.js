var request = require('request');
const fs = require('fs');
const token = require('./token-chocolopas.json');
const auth ='Bearer ' + token
const json_file = require('../json/post_vcmodel.json')

for(let i of json_file){

jsonres = JSON.stringify(i)
jsonres0 = `[${jsonres}]`

var options = {
  'method': 'POST',
  'url': 'http://autoparteschocolopas.xyz:8060/items/vc_model',
  'headers': {
    'Authorization': auth,
    'Content-Type': 'application/json',
    
    
  },
  body: jsonres0

};
request(options, function (error, response) {
  if (error) throw new Error(error);
  const res0 = response.body;
  //const re1 = JSON.parse(res0)
  //fs.writeFileSync('./directustoken.json', `"${re1.data.token}"`)
  
  
  console.log(res0)

 // fs.writeFileSync('./token-chocolopas.json', JSON.stringify(`${token}`));

});

}

 

