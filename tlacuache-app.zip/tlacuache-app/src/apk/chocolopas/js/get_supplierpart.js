var request = require('request');
const fs = require('fs');
const _ = require('lodash');

/*
token = []

var options = {
  'method': 'POST',
  'url': 'http://autoparteschocolopas.xyz:8060/auth/login',
  'headers': {
    'Authorization': 'Bearer',
    'Content-Type': 'application/json',
   },
  body: JSON.stringify({"email": "luis@chocolopas.com","password": "Noviembre"})

};
request(options, function (error, response) {
  if (error) throw new Error(error);
  //const res0 = response.body;
  //const re1 = JSON.parse(res0)
  //fs.writeFileSync('./directustoken.json', `"${re1.data.token}"`)
  res0 = response.body
  respa = JSON.parse(res0)
  respa0 = respa.data
  token0 = respa0.access_token

  token.push(token0)

  fs.writeFileSync('./token-chocolopas.json', JSON.stringify(`${token}`));

});


*/
const token = require('./token-chocolopas.json');


const auth ='Bearer ' + token



var options = {
  'method': 'GET',
  'url': 'http://autoparteschocolopas.xyz:8060/items/sp_supplierpart?page=1',
  'headers': {
    'Authorization': auth,
    'Content-Type': 'application/json',
    
    
  },
  //body: JSON.stringify({"email": "luis@chocolopas.com","password": "Noviembre"})

};
request(options, function (error, response) {
  if (error) throw new Error(error);
  const res0 = response.body;
  //const re1 = JSON.parse(res0)
  //fs.writeFileSync('./directustoken.json', `"${re1.data.token}"`)
  
  
  jsonres = JSON.parse(res0)
console.log(jsonres.data)
  var buscar = _.find(jsonres,{partnum: "39"})
  console.log(buscar)

 // fs.writeFileSync('./token-chocolopas.json', JSON.stringify(`${token}`));

});



 

