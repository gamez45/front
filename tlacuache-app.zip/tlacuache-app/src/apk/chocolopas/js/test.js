const util = require('util');
const sleep = util.promisify(setTimeout);
const fs = require('fs-extra');
const _ = require('lodash')

async function id_items () {
    const o = require('../js/porsubir.json');
    
    console.log(o.length)

    //var uO = _.uniqBy(o,'id');
    var uO =_.uniqWith(o, _.isEqual);//removed complete duplicates
    var sUo = JSON.stringify(uO)
    console.log(uO.length)
    await fs.writeFile('./porsubir.json', `${sUo}`)

}id_items ()