var request = require('request');
const fs = require('fs');
var CFd = require('./configCH').CFd;


const auth ='Bearer ' + CFd.token

console.log(auth)

var options = {
  'method': 'GET',
  'url': CFd.choco_api_url+CFd.auth_url,
  'headers': {
    'Authorization': auth,
    'Content-Type': 'application/json',
    
    
  },
  //body: JSON.stringify({"email": "luis@chocolopas.com","password": "Noviembre"})

};
request(options, function (error, response) {
  if (error) throw new Error(error);
  const res0 = response.body;
  //const re1 = JSON.parse(res0)
  //fs.writeFileSync('./directustoken.json', `"${re1.data.token}"`)
  
  
  console.log(res0)
  //console.log(jsonres.data.length)

 // fs.writeFileSync('./token-chocolopas.json', JSON.stringify(`${token}`));

});



 

