var request = require('request');
const fs = require('fs');

const token = require('./token-chocolopas.json');


const auth ='Bearer ' + token



var options = {
  'method': 'GET',
  'url': 'http://autoparteschocolopas.xyz:8060/items/pc_codemaster',
  'headers': {
    'Authorization': auth,
    'Content-Type': 'application/json',
    
    
  },
  //body: JSON.stringify({"email": "luis@chocolopas.com","password": "Noviembre"})

};
request(options, function (error, response) {
  if (error) throw new Error(error);
  const res0 = response.body;
  //const re1 = JSON.parse(res0)
  //fs.writeFileSync('./directustoken.json', `"${re1.data.token}"`)
  
  
  jsonres = JSON.parse(res0)
  console.log(jsonres)
  //console.log(jsonres.data.length)

 // fs.writeFileSync('./token-chocolopas.json', JSON.stringify(`${token}`));

});



 

