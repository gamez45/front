
const express = require('express');
const path    = require('path');
const morgan  = require('morgan');
//const cors = require('cors');
const app = express();



// Server
app.set('port', 6655);
app.set('views', path.resolve(__dirname, 'views'));
app.set('apk', path.resolve(__dirname, 'apk'));
app.set('json', path.resolve(__dirname, 'json'));


app.set('view engine', 'ejs');

// Middlewares
app.use(morgan('common'));
//app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended: false}));


// Routes

app.use(require('./routes'));
app.use(require('./routes/index'));
app.use(require('./routes/inicio'));
app.use(require('./routes/catalogo'));
app.use(require('./routes/models'));
app.use(require('./routes/basevehicleid2'));












//Publics
app.use(express.static(path.join(__dirname, 'public')));

// 404 handler
app.use((req, res, next) => {
  res.status(404).render('404');
});

module.exports = app;